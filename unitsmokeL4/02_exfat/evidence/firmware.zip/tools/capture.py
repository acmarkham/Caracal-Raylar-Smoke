import datetime
import json
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time

stage, elf_path = sys.argv[1:3]
out = Path('unitsmokeL4/02_exfat/evidence')
# The outer shell command uses rtk. Own probe-rs directly here so terminating
# this bounded monitor releases its USB handle rather than just killing a proxy.
cmd = ['probe-rs', 'run', '--chip', 'STM32L476RGTx',
       '--probe', '0483:3748', '--speed', '100', '--verify', '--preverify',
       '--non-interactive', '--disable-progressbars', '--no-location', elf_path]
process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, bufsize=1)
messages = queue.Queue()

def read_output():
    for line in process.stdout:
        messages.put((time.monotonic(), line))
    messages.put((time.monotonic(), None))

threading.Thread(target=read_output, daemon=True).start()
started = time.monotonic()
lines = []
passed = False
try:
    while time.monotonic() - started < 180:
        try:
            ts, line = messages.get(timeout=1)
        except queue.Empty:
            if process.poll() is not None:
                break
            continue
        if line is None:
            break
        lines.append(line)
        print(line.rstrip(), flush=True)
        if 'L4 EXFAT PASS' in line:
            passed = True
            break
finally:
    if process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()

(out / (stage + '.log')).write_text(''.join(lines), encoding='utf-8')
(out / (stage + '.json')).write_text(json.dumps({
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': cmd, 'pass': passed, 'host_seconds': time.monotonic() - started,
}, indent=2) + '\n')
print(stage, 'PASS' if passed else 'FAIL', flush=True)
raise SystemExit(0 if passed else 1)
